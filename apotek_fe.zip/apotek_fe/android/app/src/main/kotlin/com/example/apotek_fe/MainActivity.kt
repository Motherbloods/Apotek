package com.example.apotek_fe

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
