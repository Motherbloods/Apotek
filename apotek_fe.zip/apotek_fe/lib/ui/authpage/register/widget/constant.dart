import 'package:flutter/material.dart';

const kPrimaryColor = Color(0xFF00BF62);
const kPrimaryLightColor = Color(0xFFF1E6FF);
